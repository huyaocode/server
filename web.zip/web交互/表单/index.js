function leaveName(el){
	var txt = el.value;
	var tip = document.querySelector('.err-tip');
	if(txt === ''){
		tip.style.display = 'block';
		el.style.borderColor = 'red';
		return;
	}else{
		var reg = /^[a-zA-Z].{4,}/;
		if(!reg.test(el.value)){
			tip.style.display = 'block';
			tip.innerHTML = '昵称以字母开头，长度不小于5个字符';
			return;
		}
	}
	tip.style.display = 'none';
}

function leavePwd(el){
	var txt = el.value;
	var tip = document.querySelector('.err-pwd');
	if(txt === ''){
		tip.style.display = 'block';
		el.style.borderColor = 'red';
		return;
	}else{
		if(txt.length<8 || txt.length>16){
			tip.style.display = 'block';
			tip.innerHTML = '密码长度为8-16';
			return;
		}
		var reg = /(\d\w*[a-zA-Z]\w*)|([a-zA-Z]\w*\d\w*)/;
		if(!reg.test(el.value)){
			tip.style.display = 'block';
			tip.innerHTML = '必须包含字母和数字';
			return;
		}
	}
	document.querySelector('.tip-pwd').style.display = 'none';
}

function focusPwd(el){
	document.querySelector('.err-pwd').style.display = 'none';
	document.querySelector('.tip').style.display = 'block';
}

function focusMobile(el){
	if(el.value !== ''){
		document.querySelector('.sms').style.display = 'block';
	}
}

function leaveMobile(el){
	var sms = document.querySelector('.sms');
	if(el.value === ''){
		sms.style.display = 'none';
	}else{
		sms.style.display = 'block';
	}
}

function checkMobile(){
	var mobile = document.querySelector('.mobile');
	var reg = /^1[356789]\d{9}$/;
	if(!reg.test(mobile.value)){
		document.querySelector('.err-mobile').style.display = 'block';
		mobile.style.borderColor = 'red';
	}else{
		mobile.style.borderColor = 'black';
		document.querySelector('.err-mobile').style.display = 'none';
	}
}
