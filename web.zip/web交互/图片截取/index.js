var image = document.querySelector('img');
var container = document.querySelector('.container');
var scale = 1;
var oriWidth = 0;
var oriHeight = 0;
var startx=0,starty=0;
image.onload = function(){
	var w = image.width;
	var h = image.height;
	var scw = 600/w;
	var sch = 400/h;
	scale = scw>sch?sch:scw;
	oriWidth = scale * w;
	oriHeight = scale * h;
	startx = -(w - oriWidth)/2;
	starty = -(h - oriHeight)/2;
	updTransform();
}

function updTransform(){
	image.style.transform =
		'translate(' + startx + 'px,' + starty + 'px) scale('+ scale + ',' + scale +') ';
}

var moveFlag = 0;
var oldX = 0;
var oldY = 0;

container.addEventListener('mousedown',
	function(e){
		moveFlag = 1;
		oldX = e.clientX;
		oldY = e.clientY;
	}
);

container.addEventListener('mouseup',
	function(e){
		moveFlag = 0;
	}
);

container.addEventListener('mousemove',
	function(e){
		if(moveFlag == 0){
			return;
		}
		var dx = e.clientX - oldX;
		var dy = e.clientY - oldY;
		startx += dx;
		starty += dy;
		oldX = e.clientX;
		oldY = e.clientY;
		updTransform();
	}
);

image.addEventListener('dragstart',
	function(e){
		e.preventDefault();
	}
);

function sizeout(){
	scale += 0.1;
	updTransform();
}
function sizein(){
	scale -= 0.1;
	updTransform();
}

function crop(){
	var canvas = document.querySelector('canvas');
	var ctx = canvas.getContext('2d');
	ctx.clearRect(0,0,300,300);
	//计算裁剪位置和大小
    var x = ((image.offsetWidth*(scale-1)/2 + 150 - startx)/scale) | 0 ;
    var y = ((image.offsetHeight*(scale-1)/2 + 50 -starty)/scale) | 0;
    var w = (300/scale)|0;
    var h = (300/scale)|0;
	ctx.drawImage(image,x,y,w,h,0,0,300,300);
}


