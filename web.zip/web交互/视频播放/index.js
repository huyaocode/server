var videos;
var xhr = new XMLHttpRequest();
xhr.open("GET", "data.json", true);
xhr.onreadystatechange = function() {
	if(xhr.readyState === 4) {
		if(xhr.status === 200) {
			var r = xhr.responseText;
			r = JSON.parse(r);
			videos = r.rows;
			var container = document.querySelector("#list");
			for(var i = 0; i < videos.length; i++) {
				var div = document.createElement("div");
				div.setAttribute("data-url", videos[i].url);
				div.innerHTML = videos[i].title;
				container.appendChild(div);
				div.onclick = clickme;
			}
		}
	}
}
xhr.send(null);

function clickme(e) {
	var e1 = e || event;
	var me = e1.target;
	var url = me.dataset.url;
	document.querySelector("video").src = url;
}