(function() {
	var Model = function(config) {
		this.init(config);
		this.currentIndex = 0;
	}

	/**
	 * 初始化element
	 * @param config		配置参数
	 */
	Model.prototype.init = function(config) {
		//创建图片和容器
		var imgct = document.createElement('div');
		imgct.setAttribute('class', 'imgct');
		for(var i = 0; i < config.imgs.length; i++) {
			var img = new Image();
			img.src = config.imgs[i].url;
			img.style.width = config.width + 'px';
			img.style.height = config.height + 'px';
			imgct.appendChild(img);
		}
		imgct.style.width = config.width * config.imgs.length + 'px';
		imgct.style.height = config.height + 'px';
		config.container.style.width = config.width + 'px';
		config.container.style.height = config.height + 'px';
		config.container.appendChild(imgct);
		//创建按钮
		var btnLeft = document.createElement('button');
		btnLeft.innerHTML = '<';
		btnLeft.setAttribute('class', 'btnleft');
		var btnRight = document.createElement('button');
		btnRight.innerHTML = '>';
		btnRight.setAttribute('class', 'btnright');
		config.container.appendChild(btnLeft);
		config.container.appendChild(btnRight);
		this.imgct = imgct;
		this.config = config;

		//创建小圆圈
		this.circles = [];
		var circlect1 = document.createElement('div');
		circlect1.setAttribute('class', 'circlect1');
		var circlect2 = document.createElement('div');
		circlect2.setAttribute('class', 'circlect2');
		circlect1.appendChild(circlect2);
		for(var i = 0; i < config.imgs.length; i++) {
			var c = document.createElement('span');
			if(i == 0) {
				c.setAttribute('class', 'circle2');
			} else {
				c.setAttribute('class', 'circle1');
			}
			circlect2.appendChild(c);
			this.circles.push(c);
		}
		config.container.appendChild(circlect1);
		this.initEvent(btnLeft, btnRight);
	}

	/**
	 * 初始化事件
	 * @param btnLeft 左按钮
	 * @param btnRight 右按钮
	 */
	Model.prototype.initEvent = function(btnLeft, btnRight) {
		var me = this;
		//左按钮事件
		btnLeft.addEventListener('click', function() {
			me.moveTo(me.currentIndex-1);
		});
		//右按钮事件
		btnRight.addEventListener('click', function() {
			me.moveTo(me.currentIndex+1);
		});

		//圆圈事件
		for(var i = 0; i < me.circles.length; i++) {
			me.circles[i].addEventListener('click', function(e) {
				var el = e.target;
				for(var j = 0; j < me.circles.length; j++) {
					if(el === me.circles[j]) {
						me.moveTo(j);
						break;
					}
				}
			});
		}

	}

	/**
	 * 移动到指定index
	 * @param index 目标index
	 */
	Model.prototype.moveTo = function(index) {
		var me = this;
		//索引不变或超出范围，不移动
		if(me.currentIndex === index || index < 0 || index >= me.circles.length) {
			return;
		}
		//修改当前圆圈状态
		me.circles[me.currentIndex].style.backgroundColor = '#fff';
		me.currentIndex = index;
		//设置新圆圈
		me.circles[index].style.backgroundColor = '#f00';
		me.imgct.style.transform =
			'translate(' + (-me.currentIndex * me.config.width) + 'px,0)';
	}
	//暴露给全局
	window.Slider = Model;

}());