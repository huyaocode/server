var canvas = document.querySelector('#canvas1');
var ctx = canvas.getContext('2d');
var colIndex = [];

function drawGrid(){
	ctx.fillStyle='#000000';
	ctx.beginPath();
	//划竖线
	for(var i=0;i<5;i++){
		ctx.moveTo(i*100,0);
		ctx.lineTo(i*100,600);
		ctx.stroke();
	}

	//横线
	for(var i=0;i<7;i++){
		ctx.moveTo(0,i*100);
		ctx.lineTo(400,i*100);
		ctx.stroke();
	}
	ctx.closePath();
}

function genColIndex(){
	for(var i=0;i<6;i++){
		colIndex.push((Math.random() * 4) | 0);
	}
}

function drawBlack(){
	ctx.fillStyle = '#000000';
	for(var i=0;i<6;i++){
		var col = colIndex[i] * 100;
		var row = i*100;
		ctx.fillRect(col,row,100,100);
	}
}

function clickme(){
	var e = event;
	var row = e.clientY/100|0;
	var col = e.clientX/100|0;
	//踩中最后一行的黑块
	if(row === 5 && col === colIndex[5]){
		ctx.clearRect(0,0,400,600);
		drawGrid();
		colIndex.pop();
		colIndex.unshift((Math.random() * 4) | 0);
		drawBlack();
	}else if(colIndex[row] !== col){ //踩中白块
		alert("踩中白块了，game over！");
	}
}

drawGrid();
genColIndex();
drawBlack();
